#include <stdio.h>
int main(void)
{
	int day[12] = { 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
	int i;

	for (i = 1; i <= 12; i++)
	{
		printf("%2d���� %2d����\n", i, day[i-1]);
	}
}