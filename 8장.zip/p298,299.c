//p 298-5��
#include <stdio.h>
//#define v 201

int main(void)
{
	int i;
//	int v = 201
//	int arr[v];
	int arr[200+1];

	for(i = 0; i < 201; i++)
	{
		arr[i] = i;
		printf("arry[%d] = %d\n", i, arr[i]);
	}
}

//p299-10��
#include <stdio.h>
int main(void)
{
	int i;

	int a[3] = { 0, 1, 2 };	
	int b[3];							

	for(i=0; i < 3; i++)	
		b[i] = a[i];
	return 0;
}

//p299-11��
#include <stdio.h>
int main(void)
{
	int array[3][3] = {{1, 2, 3},{3, 4}, {5}};
	int r, c;

	for(r = 0; r < 3; r++)
	{
		for(c = 0; c < 3; c++)
		{
			printf("%d ", array[r][c]);
		}
		printf("\n");
	}
	return 0;
}