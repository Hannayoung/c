#include <stdio.h>
#include <math.h>

double dist_2d(int , int, int, int);

int main(void)
{
	int x1 = 1, y1 = 2, x2 = 11, y2 = 12;
	printf("����(%d,%d)�� (%d,%d)�� �Ÿ� : %lf\n", x1, y1, x2, y2, dist_2d(x1,y1,x2,y2));

}

double dist_2d(int a, int b, int c, int d)
{
	double v;
	v= sqrt((double)(a-c)*(a-c) + (b-d)*(b-d));
	return v;
}