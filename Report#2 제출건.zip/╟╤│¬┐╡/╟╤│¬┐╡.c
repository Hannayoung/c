#include <stdio.h>
#define SIZE 13

int inspect(int ISBN[])
{
 int i, s, result=0;
  int result1=0, result2=0;
 for(i=0; i<SIZE; i++)
 {
  printf("��ȣ�� �Է��Ͻÿ�: ");
  scanf("%d",&ISBN[i]);
 
  if( i % 2 == 1){
   result1  = 3*ISBN[i];
  result += result1;
  }
  else if(i %2 == 0){
   result2 = 1*ISBN[i];
  result += result2;
  }
 
 }
 printf("\n");
 printf("ISBN��ȣ�� �Է��Ͻÿ�: ");
 for(i=0;i<SIZE;i++)
  printf("%3d",ISBN[i]);
 printf("\n");

 s= result % 10;

 if(s == 0)
  return 1;
 else if(s != 0)
  return 0;
}

int main()
{
 int ISBN[SIZE];
 int *p, a;
 p=ISBN;
 
 a=inspect(p);

 if(a == 1)
  printf("��ȿ�� ISBN��ȣ�Դϴ�.\n");

 else if(a == 0)
  printf("��ȿ���� ���� ISBN��ȣ�Դϴ�.\n");
 
 else
  return 0;
}
